<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" type="text/css" href="../styles/css.css"/>

</head>
<body>
    <!-- services -->
    <div class="services">
        <!--text-->
        <div class="services-text ">
            <p>Tompel Sleepwell</p>
            <p>lokasi: Jl. Jepun - Karang Mas Sejahtera, Jimbaran-Bali, Jimbaran, Kuta Selatan, Bali, Indonesia, 80361.</p>
            <p>fasilitas: AC, Restaurant, Swimming Pool, 24-Hour Front Desk, Parking, Elevator, WiFi</p>
        </div>
         
        <div class="box-container">
        <!--- 1 --->
            <div class="box-1">
                <p class="heading"></p>
                <p class="details">kamar</p>
            </div>
        <!--- 2 --->
            <div class="box-2">
                <p class="heading"></p>
                <p class="details">kamarmandi</p>
            </div>
        <!--- 3 --->
            <div class="box-3">
                <p class="heading"></p>
                <p class="details">kasur</p>
        </div>
        <!--- 1 --->
            <div class="box-4">
                <p class="heading"></p>
                <p class="details">cermin</p>
            </div>
        <!--- 2 --->
            <div class="box-5">
                <p class="heading"></p>
                <p class="details">sarapan</p>
            </div>
        <!--- 3 --->
            <div class="box-6">
                <p class="heading"></p>
                <p class="details">pelayanan</p>
        </div>
            
        <a href="pesann.php"><button class="kembali">Kembali</button></a>
        <a href="#"><button class="lanjut">up</button></a>
        <a href="#"><button class="lanjut">pesan</button></a>
    </div>    
<!-- 
    <h2 class="bg-back"></h2>
    <ul>
        <p></p>
        <a href="userpage.php"><button class="back">kembali</button></a>
        
    </ul> -->

</body>
</html>